#!/bin/sh
clear
Font_Black="\033[30m"
Font_Red="\033[31m"
Font_Green="\033[32m"
Font_Yellow="\033[33m"
Font_Blue="\033[34m"
Font_Purple="\033[35m"
Font_SkyBlue="\033[36m"
Font_White="\033[37m"
Font_Suffix="\033[0m"
config="https://git.coiaprant.top/CoiaPrant/SecureTunnel/-/raw/master/files/config.json"
version=$(wget -qO- https://git.coiaprant.top/api/v4/projects/CoiaPrant%2FSecureTunnel/releases | grep "tag_name" | head -n 1 | awk -F ":" '{print $2}' | awk -F "," '{print $1}' | sed 's/\"//g;s/,//g;s/ //g' | awk -F "v" '{print $2}')

echo -e "${Font_SkyBlue}SecureTunnel installation script${Font_Suffix}"
echo -e "${Font_Yellow} ** Checking system info...${Font_Suffix}"

os=$(uname -s | tr [:upper:] [:lower:])
arch=$(uname -m)
cpu_flags=$(cat /proc/cpuinfo | grep flags | head -n 1 | awk -F ':' '{print $2}')

case ${arch} in
x86)
    arch="386"
    ;;
x86_64)
    if [[ ${cpu_flags} == *avx512* ]]; then
        arch="amd64v4"
    elif [[ ${cpu_flags} == *avx2* ]]; then
        arch="amd64v3"
    elif [[ ${cpu_flags} == *sse3* ]]; then
        arch="amd64v2"
    else
        arch="amd64v1"
    fi
    ;;
aarch64)
    arch="arm64"
    ;;
esac

url="https://git.coiaprant.top/CoiaPrant/SecureTunnel/-/releases/v"${version}"/downloads/SecureTunnel_"${version}"_"${os}"_"${arch}".tar.gz"
echo -e "${Font_Yellow} ** Checking wget...${Font_Suffix}"

wget -V >/dev/null 2>&1
if [ $? -ne 0 ]; then
    echo -e "${Font_Red} [Error] Please install wget${Font_Suffix}"
    exit 1
fi
echo -e "${Font_Green} [Success] Wget found${Font_Suffix}"

echo -e "${Font_Yellow} ** Prepare for installation...${Font_Suffix}"
systemctl stop SecureTunnel >/dev/null 2>&1

echo -e "${Font_Yellow} ** Creating Program Dictionary...${Font_Suffix}"
if [ ! -d "/opt/SecureTunnel/" ]; then
    mkdir /opt/SecureTunnel/ >/dev/null 2>&1
    mkdir /opt/SecureTunnel/ssl/ >/dev/null 2>&1
fi

echo -e "${Font_Yellow} ** Showing the node infomation${Font_Suffix}"
echo -e " Version: " ${version}

echo -e "${Font_Yellow} ** Downloading files and configuring...${Font_Suffix}"
if [[ -e "/usr/bin/systemctl" ]] || [[ -e "/bin/systemctl" ]]; then
    wget -qO /etc/systemd/system/SecureTunnel.service https://git.coiaprant.top/CoiaPrant/SecureTunnel/-/raw/master/systemd/SecureTunnel.service
    ln -sf /etc/systemd/system/SecureTunnel.service /etc/systemd/system/multi-user.target.wants/SecureTunnel.service
    systemctl daemon-reload >/dev/null 2>&1
    systemctl enable SecureTunnel >/dev/null 2>&1
else
    echo -e "${Font_Yellow}Not Found systemd, skip to configure system service. ${Font_Suffix}"
fi

wget -qO /usr/bin/update-securetunnel https://git.coiaprant.top/CoiaPrant/SecureTunnel/-/raw/master/files/update-script
wget -qO /opt/SecureTunnel/setting.json https://git.coiaprant.top/CoiaPrant/SecureTunnel/-/raw/master/files/default-setting.json
chmod 777 /usr/bin/update-securetunnel
wget -qO /tmp/SecureTunnel.tar.gz ${url}
tar -xvzf /tmp/SecureTunnel.tar.gz -C /tmp/ >/dev/null 2>&1
rm -rf /opt/SecureTunnel/SecureTunnel >/dev/null 2>&1
mv -f /tmp/SecureTunnel /opt/SecureTunnel/SecureTunnel >/dev/null 2>&1
rm -rf /tmp/* >/dev/null 2>&1
chmod 777 /opt/SecureTunnel/SecureTunnel
wget -qO /opt/SecureTunnel/config.json "${config}"

wget -qO /tmp/panel.tar.gz "https://git.coiaprant.top/CoiaPrant/SecureTunnel/-/archive/v${version}/SecureTunnel-v${version}.tar.gz"
tar -xvzf /tmp/panel.tar.gz -C /tmp/ >/dev/null 2>&1
rm -rf /opt/SecureTunnel/public >/dev/null 2>&1
mv -f /tmp/SecureTunnel-v${version}/public /opt/SecureTunnel/public >/dev/null 2>&1
rm -rf /tmp/* >/dev/null 2>&1

echo -e "${Font_Yellow} ** Configuring system...${Font_Suffix}"

read -ep "Do you want to use our sysctl.conf ? [y/n]" ask
if [[ "${ask}" == "y" || "${ask}" == "Y" ]]; then
    echo "# nofile
vm.swappiness = 10
fs.file-max = 1000000
fs.inotify.max_user_instances = 8192
fs.pipe-max-size = 1048576
fs.pipe-user-pages-hard = 0
fs.pipe-user-pages-soft = 0
net.ipv4.conf.all.rp_filter = 0
net.ipv4.conf.default.rp_filter = 0

# socket status
net.ipv4.tcp_syncookies = 1
net.ipv4.tcp_fin_timeout = 30
net.ipv4.tcp_tw_timeout = 10
net.ipv4.tcp_tw_reuse = 1
net.ipv4.tcp_timestamps = 1
net.ipv4.tcp_keepalive_time = 1200
net.ipv4.tcp_keepalive_probes = 3
net.ipv4.tcp_keepalive_intvl = 15
net.ipv4.ip_local_port_range = 1024 65535
net.ipv4.tcp_max_syn_backlog = 8192
net.ipv4.tcp_max_tw_buckets = 3000
net.ipv4.route.gc_timeout = 100
net.ipv4.tcp_syn_retries = 2
net.ipv4.tcp_synack_retries = 2

# tcp window
net.core.wmem_default = 262144
net.core.wmem_max = 67108864
net.core.somaxconn = 3276800
net.core.optmem_max = 81920
net.core.rmem_default = 262144
net.core.rmem_max = 67108864
net.core.netdev_max_backlog = 400000
net.core.netdev_budget = 600
net.ipv4.tcp_max_orphans = 3276800

# forward ipv4
net.ipv4.conf.all.route_localnet=1
net.ipv4.tcp_no_metrics_save=1
net.ipv4.tcp_ecn=0
net.ipv4.tcp_frto=0
net.ipv4.tcp_mtu_probing=0
net.ipv4.tcp_rfc1337=0
net.ipv4.tcp_sack=1
net.ipv4.tcp_fack=1
net.ipv4.tcp_window_scaling=1
net.ipv4.tcp_adv_win_scale=1
net.ipv4.tcp_moderate_rcvbuf=1
net.ipv4.tcp_mem = 786432 2097152 3145728 
net.ipv4.tcp_rmem = 4096 524288 67108864
net.ipv4.tcp_wmem = 4096 524288 67108864
net.ipv4.udp_rmem_min=8192
net.ipv4.udp_wmem_min=8192
net.core.default_qdisc=fq
net.ipv4.tcp_congestion_control=bbr

# deny attack
net.inet.udp.checksum=1

# netfiliter iptables
net.netfilter.nf_conntrack_tcp_timeout_fin_wait = 30
net.netfilter.nf_conntrack_tcp_timeout_time_wait = 30
net.netfilter.nf_conntrack_tcp_timeout_close_wait = 15
net.netfilter.nf_conntrack_tcp_timeout_established = 350
net.netfilter.nf_conntrack_max = 25000000
net.netfilter.nf_conntrack_buckets = 25000000" >/etc/sysctl.conf

    echo "* soft nofile 1048576
    * hard nofile 1048576
    * soft nproc 1048576
    * hard nproc 1048576
    * soft core 1048576
    * hard core 1048576
    * hard memlock unlimited
    * soft memlock unlimited
    " >/etc/security/limits.conf

    sysctl -p >/dev/null 2>&1
    sysctl --system >/dev/null 2>&1
fi

if [[ -f "/usr/sbin/iptables-save" ]] && [[ "$(iptables-save)" != "" ]]; then
    echo -e "${Font_Red} Please stop your firewall. ${Font_Suffix}"
fi

echo -e "${Font_Yellow} ** Starting Program...${Font_Suffix}"
systemctl start SecureTunnel >/dev/null 2>&1

echo -e "${Font_Green} [Success] Completed installation${Font_Suffix}"
echo -e "${Font_SkyBlue} [Web Panel] http://your_ip:14514/ Username: admin Password: SecureTunnelAdmin Setting-file: /opt/SecureTunnel/setting.json"
echo -e "${Font_SkyBlue} [Tip] Please Reboot${Font_Suffix}"
