var domparser = new DOMParser();

var newRule = new mdui.Dialog("#addRule");
var editRule = new mdui.Dialog("#editRule");
var upload = new mdui.Dialog("#uploadFile");
var protocol = {
  secure_server: "Secure隧道 (出口)",
  secure_client: "Secure隧道 (入口)",
  tls_server: "TLS隧道 (出口)",
  tls_client: "TLS隧道 (入口)",
  quic_server: "QUIC隧道 (出口)",
  quic_client: "QUIC隧道 (入口)",
  websocket_server: "WebSocket隧道 (出口)",
  websocket_client: "WebSocket隧道 (入口)",
  cloudflare: "Cloudflare隧道",
};

$("#newrule").on("click", function () {
  $("#add_name").val("");
  $("#add_listen_port").val("");
  $("#add_https").removeAttr("checked");
  $("#add_pool").val("");
  $("#add_cert").val("");
  $("#add_key").val("");
  $("#add_minspeed").val("");

  $("#add_mode option:selected").removeAttr("selected");
  $("#add_proxyprotocol option:selected").removeAttr("selected");
  $("#add_protocol option:selected").removeAttr("selected");

  $("#tag_add_target").attr("style", "display: none;");
  $("#tag_add_path").attr("style", "display: none;");
  $("#tag_add_pool").attr("style", "display: none;");
  $("#tag_add_proxyprotocol").attr("style", "display: none;");
  $("#tag_add_https").attr("style", "display: none;");
  $("#tag_add_cert").attr("style", "display: none;");
  $("#tag_add_key").attr("style", "display: none;");
  $("#tag_add_minspeed").attr("style", "display: none;");
  $("#tag_add_paths").empty();
  $("#tag_edit_paths").empty();
  $("#tag_add_targets").empty();
  $("#tag_edit_targets").empty();
  $("#add_path").val("");
  newRule.open();
});

$("#upload").on("click", function () {
  $("#file").val("");
  upload.open();
});

$("#add_protocol").on("change", function () {
  var protocol = $("#add_protocol option:selected").val();
  $("#tag_add_pool").attr("style", "display: none;");
  $("#tag_add_proxyprotocol").attr("style", "display: none;");
  $("#tag_add_https").attr("style", "display: none;");
  $("#tag_add_cert").attr("style", "display: none;");
  $("#tag_add_key").attr("style", "display: none;");
  $("#tag_add_target").attr("style", "display: none;");
  $("#tag_add_path").attr("style", "display: none;");
  $("#tag_add_minspeed").attr("style", "display: none;");

  switch (protocol) {
    case "secure_server": {
      $("#tag_add_target").removeAttr("style");
      $("#tag_add_key").removeAttr("style");
      return;
    }

    case "secure_client": {
      $("#tag_add_target").removeAttr("style");
      $("#tag_add_proxyprotocol").removeAttr("style");
      $("#tag_add_pool").removeAttr("style");
      $("#tag_add_key").removeAttr("style");
      return;
    }

    case "tls_server": {
      $("#tag_add_target").removeAttr("style");
      $("#tag_add_cert").removeAttr("style");
      $("#tag_add_key").removeAttr("style");
      return;
    }

    case "tls_client": {
      $("#tag_add_target").removeAttr("style");
      $("#tag_add_proxyprotocol").removeAttr("style");
      $("#tag_add_pool").removeAttr("style");
      return;
    }

    case "quic_server": {
      $("#tag_add_target").removeAttr("style");
      $("#tag_add_cert").removeAttr("style");
      $("#tag_add_key").removeAttr("style");
      return;
    }

    case "quic_client": {
      $("#tag_add_proxyprotocol").removeAttr("style");
      $("#tag_add_target").removeAttr("style");
      break;
    }

    case "websocket_server": {
      $("#tag_add_target").removeAttr("style");
      $("#tag_add_cert").removeAttr("style");
      $("#tag_add_key").removeAttr("style");
      return;
    }

    case "websocket_client": {
      $("#tag_add_target").removeAttr("style");
      $("#tag_add_proxyprotocol").removeAttr("style");
      $("#tag_add_pool").removeAttr("style");
      return;
    }

    case "cloudflare": {
      $("#tag_add_https").removeAttr("style");
      $("#tag_add_minspeed").removeAttr("style");
      $("#tag_add_path").removeAttr("style");
      return;
    }
  }
});

$("#edit_protocol").on("change", function () {
  $("#tag_edit_pool").attr("style", "display: none;");
  $("#tag_edit_proxyprotocol").attr("style", "display: none;");
  $("#tag_edit_https").attr("style", "display: none;");
  $("#tag_edit_cert").attr("style", "display: none;");
  $("#tag_edit_key").attr("style", "display: none;");
  $("#tag_edit_target").attr("style", "display: none;");
  $("#tag_edit_path").attr("style", "display: none;");
  $("#tag_edit_minspeed").attr("style", "display: none;");

  var protocol = $("#edit_protocol option:selected").val();
  switch (protocol) {
    case "secure_server": {
      $("#tag_edit_target").removeAttr("style");
      $("#tag_edit_key").removeAttr("style");
      return;
    }

    case "secure_client": {
      $("#tag_edit_target").removeAttr("style");
      $("#tag_edit_proxyprotocol").removeAttr("style");
      $("#tag_edit_pool").removeAttr("style");
      $("#tag_edit_key").removeAttr("style");
      return;
    }

    case "tls_server": {
      $("#tag_edit_target").removeAttr("style");
      $("#tag_edit_cert").removeAttr("style");
      $("#tag_edit_key").removeAttr("style");
      return;
    }

    case "tls_client": {
      $("#tag_edit_target").removeAttr("style");
      $("#tag_edit_proxyprotocol").removeAttr("style");
      $("#tag_edit_pool").removeAttr("style");
      return;
    }

    case "quic_server": {
      $("#tag_edit_target").removeAttr("style");
      $("#tag_edit_cert").removeAttr("style");
      $("#tag_edit_key").removeAttr("style");
      return;
    }

    case "quic_client": {
      $("#tag_edit_proxyprotocol").removeAttr("style");
      $("#tag_edit_target").removeAttr("style");
      break;
    }

    case "websocket_server": {
      $("#tag_edit_target").removeAttr("style");
      $("#tag_edit_cert").removeAttr("style");
      $("#tag_edit_key").removeAttr("style");
      return;
    }

    case "websocket_client": {
      $("#tag_edit_target").removeAttr("style");
      $("#tag_edit_proxyprotocol").removeAttr("style");
      $("#tag_edit_pool").removeAttr("style");
      return;
    }

    case "cloudflare": {
      $("#tag_edit_https").removeAttr("style");
      $("#tag_edit_minspeed").removeAttr("style");
      $("#tag_edit_path").removeAttr("style");
      return;
    }
  }
});

$.ajax({
  method: "GET",
  url: "/api/getConfig",
  dataType: "json",
})
  .done(function (response) {
    if (response.Ok) {
      $("#version").text(`当前版本号: ${response.Version}`);

      var trbody = "";
      for (id in response.Rules) {
        var rule = response.Rules[id];

        trbody = `<tr>
            <th>${id}</th>
            <th>${rule.Name}</th>
            <th>${rule.Listen}</th>`;

        if (rule.Protocol == "cloudflare") {
          trbody += `<th>------</th>`;
        } else {
          trbody += `<th>${rule.Targets[0].Host}:${rule.Targets[0].Port}</th>`;
        }

        trbody += `<th>${protocol[rule.Protocol]}</th>
        <th>
            <span id="edit_${id}" class="mdui-btn mdui-btn-icon">
                <i class="mdui-icon material-icons">edit</i>
            </span>
            <span id="delete_${id}" class="mdui-btn mdui-btn-icon">
                <i class="mdui-icon material-icons">delete</i>
            </span>
        </th>
        </tr>`;

        $("#rule_list").append(trbody);

        $(`#edit_${id}`).on("click", function () {
          edit_rule(id);
        });

        $(`#delete_${id}`).on("click", function () {
          delete_rule(id);
        });
      }
    } else sendmsg(response.Msg);
  })
  .fail(function () {
    sendmsg("未能获取服务器数据, 请检查网络是否正常");
  });

$("#upload_enter").on("click", function () {
  var postdata = $("#file").prop("files")[0];
  if (!postdata) {
    sendmsg("请选择文件");
    return;
  }

  $.ajax({
    method: "POST",
    url: "/api/uploadFile",
    dataType: "json",
    data: postdata,
    contentType: "application/json",
    async: false,
    cache: false,
    processData: false,
  })
    .done(function (response) {
      if (response.Ok) {
        sendmsg("导入成功");
        location.reload();
      } else sendmsg(response.Msg);
    })
    .fail(function () {
      sendmsg("请求失败, 请检查网络是否正常");
    });
});

$("#add_enter").on("click", function () {
  var name = $("#add_name").val();
  var mode = Number($("#add_mode option:selected").val());

  var listen_port = Number($("#add_listen_port").val());
  var protocol = $("#add_protocol option:selected").val();
  var proxyprotocol = Number($("#add_proxyprotocol option:selected").val());

  var cert = $("#add_cert").val();
  var key = $("#add_key").val();
  var pool = Number($("#add_pool").val());
  var minspeed = Number($("#add_minspeed").val());

  var targets = [];
  var paths = {};

  if (!listen_port) {
    sendmsg("请填完所有选项");
    return;
  }

  switch (protocol) {
    case "empty": {
      sendmsg("请填完所有选项");
      return;
    }

    case "secure_server": {
      if (!key) {
        sendmsg("请填完所有选项");
        return;
      }
      break;
    }

    case "secure_client": {
      if (!key || !pool) {
        sendmsg("请填完所有选项");
        return;
      }
      break;
    }

    case "tls_server": {
      if (!cert || !key) {
        sendmsg("请填完所有选项");
        return;
      }
      break;
    }

    case "tls_client": {
      if (!pool) {
        sendmsg("请填完所有选项");
        return;
      }
      break;
    }

    case "quic_server": {
      if (!cert || !key) {
        sendmsg("请填完所有选项");
        return;
      }
      break;
    }

    case "quic_client": {
      break;
    }

    case "websocket_server": {
      if (!cert || !key) {
        sendmsg("请填完所有选项");
        return;
      }
      break;
    }

    case "websocket_client": {
      if (!pool) {
        sendmsg("请填完所有选项");
        return;
      }
      break;
    }

    case "cloudflare": {
      if ($("#add_https").prop("checked")) {
        cert = "ssl/{id}.pem";
        key = "ssl/{id}.key";
      }

      break;
    }
  }

  var exit = false;
  $("input[path]").each(function (_, _) {
    if (!$(this).val()) {
      exit = true;
      return;
    }

    var path = $(this).attr("path");
    paths[path] = $(this).val();
  });

  $("input[target][type=text]").each(function (index, item) {
    if (!item.value) {
      exit = true;
      return;
    }

    var port = Number($("input[target=" + index + "][type=number]").val());
    if (!port || port < 1 || port > 65535) {
      exit = true;
      return;
    }

    targets.push({
      Host: item.value,
      Port: port,
    });
  });

  if (exit) {
    sendmsg("请填完所有选项");
    return;
  }

  $.ajax({
    method: "POST",
    url: "/api/addRule",
    dataType: "json",
    contentType: "application/json",
    data: JSON.stringify({
      Name: name,
      Mode: mode,

      Protocol: protocol,
      Listen: listen_port,
      Targets: targets,

      ProxyProtocol: proxyprotocol,
      Pool: pool,
      MinSpeed: minspeed,

      Cert: cert,
      Key: key,
      Paths: paths,
    }),
  })
    .done(function (response) {
      if (response.Ok) {
        sendmsg("添加成功");
        location.reload();
      } else sendmsg(response.Msg);
    })
    .fail(function () {
      sendmsg("请求失败, 请检查网络是否正常");
    });
});

$("#edit_enter").on("click", function () {
  var id = $("#edit_id").val();
  var name = $("#edit_name").val();
  var mode = Number($("#edit_mode option:selected").val());

  var listen_port = Number($("#edit_listen_port").val());
  var protocol = $("#edit_protocol option:selected").val();
  var proxyprotocol = Number($("#edit_proxyprotocol option:selected").val());

  var cert = $("#edit_cert").val();
  var key = $("#edit_key").val();
  var pool = Number($("#edit_pool").val());
  var minspeed = Number($("#minspeed").val());

  var targets = [];
  var paths = {};

  if (!id) {
    return;
  }

  if (!listen_port) {
    sendmsg("请填完所有选项");
    return;
  }

  switch (protocol) {
    case "empty": {
      sendmsg("请填完所有选项");
      return;
    }

    case "secure_server": {
      if (!key) {
        sendmsg("请填完所有选项");
        return;
      }
      break;
    }

    case "secure_client": {
      if (!key || !pool) {
        sendmsg("请填完所有选项");
        return;
      }
      break;
    }

    case "tls_server": {
      if (!cert || !key) {
        sendmsg("请填完所有选项");
        return;
      }
      break;
    }

    case "tls_client": {
      if (!pool) {
        sendmsg("请填完所有选项");
        return;
      }
      break;
    }

    case "quic_server": {
      if (!cert || !key) {
        sendmsg("请填完所有选项");
        return;
      }
      break;
    }

    case "quic_client": {
      break;
    }

    case "websocket_server": {
      if (!cert || !key) {
        sendmsg("请填完所有选项");
        return;
      }
      break;
    }

    case "websocket_client": {
      if (!pool) {
        sendmsg("请填完所有选项");
        return;
      }
      break;
    }

    case "cloudflare": {
      if ($("#edit_https").prop("checked")) {
        cert = "ssl/{id}.pem";
        key = "ssl/{id}.key";
      }

      break;
    }
  }

  var exit = false;
  $("input[path]").each(function (_, _) {
    if (!$(this).val()) {
      exit = true;
      return;
    }

    var path = $(this).attr("path");
    paths[path] = $(this).val();
  });

  $("input[target][type=text]").each(function (index, item) {
    if (!item.value) {
      exit = true;
      return;
    }

    var port = Number($("input[target=" + index + "][type=number]").val());
    if (!port || port < 1 || port > 65535) {
      exit = true;
      return;
    }

    targets.push({
      Host: item.value,
      Port: port,
    });
  });

  if (exit) {
    sendmsg("请填完所有选项");
    return;
  }

  $.ajax({
    method: "POST",
    url: "/api/editRule?id=" + id,
    dataType: "json",
    contentType: "application/json",
    data: JSON.stringify({
      Name: name,
      Mode: mode,

      Protocol: protocol,
      Listen: listen_port,
      Targets: targets,

      ProxyProtocol: proxyprotocol,
      Pool: pool,
      MinSpeed: minspeed,

      Cert: cert,
      Key: key,
      Paths: paths,
    }),
  })
    .done(function (response) {
      if (response.Ok) {
        sendmsg("添加成功");
        location.reload();
      } else sendmsg(response.Msg);
    })
    .fail(function () {
      sendmsg("请求失败, 请检查网络是否正常");
    });
});

$("#add_cancel").on("click", function () {
  newRule.close();
});

$("#edit_cancel").on("click", function () {
  editRule.close();
});

$("#upload_cancel").on("click", function () {
  upload.close();
});

$("#add_target").on("click", function () {
  var id = 0;
  for (id = 0; $(`[target=${id}]`).length > 0; id++) {}

  var html = `<li target="${id}" class="mdui-list-item">
  <div class="mdui-list-item mdui-textfield">
      <input target="${id}" class="mdui-textfield-input" type="text" placeholder="127.0.0.1" />
  </div>
  <div class="mdui-list-item mdui-textfield">
      <input target="${id}" class="mdui-textfield-input" type="number" min="1" max="65535" placeholder="8080" />
  </div>
  <button target="${id}" class="mdui-btn mdui-btn-icon mdui-btn-raised mdui-shadow-4 mdui-color-theme mdui-ripple">
      <i class="mdui-list-item-icon mdui-icon material-icons">delete</i>
  </button>
</li>`;
  $("#tag_add_targets").append(html);

  $(`button[target="${id}"]`).on("click", function () {
    $(`li[target="${id}"]`).remove();
  });
});

$("#edit_target").on("click", function () {
  var id = 0;
  for (id = 0; $(`[target=${id}]`).length > 0; id++) {}

  var html = `<li target="${id}" class="mdui-list-item">
  <div class="mdui-list-item mdui-textfield">
      <input target="${id}" class="mdui-textfield-input" type="text" placeholder="127.0.0.1" />
  </div>
  <div class="mdui-list-item mdui-textfield">
      <input target="${id}" class="mdui-textfield-input" type="number" min="1" max="65535" placeholder="8080" />
  </div>
  <button target="${id}" class="mdui-btn mdui-btn-icon mdui-btn-raised mdui-shadow-4 mdui-color-theme mdui-ripple">
      <i class="mdui-list-item-icon mdui-icon material-icons">delete</i>
  </button>
</li>`;
  $("#tag_edit_targets").append(html);

  $(`button[target="${id}"]`).on("click", function () {
    $(`li[target="${id}"]`).remove();
  });
});

$("#add_path").on("click", function () {
  var path = $("#add_path_name").val();
  if (!path) {
    sendmsg("Path不能为空");
    return;
  }

  if (path == "/" || path == "/speedtest") {
    sendmsg("Path不可用");
    return;
  }

  if (path.indexOf("/") == -1) {
    sendmsg("Path需要以 / 开头");
    return;
  }

  if ($(`[path="${path}"]`).length > 0) {
    sendmsg("Path已存在");
    return;
  }

  var html = `<li path="${path}" class="mdui-list-item">${path}
  <div class="mdui-list-item mdui-textfield">
      <input path="${path}" class="mdui-textfield-input" type="text" placeholder="127.0.0.1:8080" />
  </div>
  <button path="${path}" class="mdui-btn mdui-btn-icon mdui-btn-raised mdui-shadow-4 mdui-color-theme mdui-ripple">
      <i class="mdui-list-item-icon mdui-icon material-icons">delete</i>
  </button>
</li>`;
  $("#tag_add_paths").append(html);

  $(`button[path="${path}"]`).on("click", function () {
    $(`li[path="${path}"]`).remove();
  });
});

$("#edit_path").on("click", function () {
  var path = $("#edit_path_name").val();
  if (!path) {
    sendmsg("Path不能为空");
    return;
  }

  if (path == "/" || path == "/speedtest") {
    sendmsg("Path不可用");
    return;
  }

  if (path.indexOf("/") == -1) {
    sendmsg("Path需要以 / 开头");
    return;
  }

  if ($(`[path="${path}"]`).length > 0) {
    sendmsg("Path已存在");
    return;
  }

  var html = `<li path="${path}" class="mdui-list-item">${path}
  <div class="mdui-list-item mdui-textfield">
      <input path="${path}" class="mdui-textfield-input" type="text" placeholder="127.0.0.1:8080" />
  </div>
  <button path="${path}" class="mdui-btn mdui-btn-icon mdui-btn-raised mdui-shadow-4 mdui-color-theme mdui-ripple">
      <i class="mdui-list-item-icon mdui-icon material-icons">delete</i>
  </button>
</li>`;
  $("#tag_edit_paths").append(html);

  $(`button[path="${path}"]`).on("click", function () {
    $(`li[path="${path}"]`).remove();
  });
});

function edit_rule(id) {
  $.ajax({
    method: "GET",
    url: "/api/getRule?id=" + id,
    dataType: "json",
  })
    .done(function (response) {
      if (response.Ok) {
        $("#edit_id").val(id);
        $("#edit_name").val(response.Rule.Name);
        $("#edit_listen_port").val(response.Rule.Listen);
        $("#edit_https").removeAttr("checked");
        $("#edit_pool").val(response.Rule.Pool);
        $("#edit_cert").val(response.Rule.Cert);
        $("#edit_key").val(response.Rule.Key);
        if (response.Rule.MinSpeed == null) response.Rule.MinSpeed = 0;
        $("#edit_minspeed").val(response.Rule.MinSpeed);

        $("#edit_mode option:selected").removeAttr("selected");
        $("#edit_mode")
          .find("option[value=" + response.Rule.Mode + "]")
          .attr("selected", true);

        $("#edit_proxyprotocol option:selected").removeAttr("selected");
        $("#edit_proxyprotocol")
          .find("option[value=" + response.Rule.ProxyProtocol + "]")
          .attr("selected", true);

        $("#edit_protocol option:selected").removeAttr("selected");
        $("#edit_protocol")
          .find("option[value=" + response.Rule.Protocol + "]")
          .attr("selected", true);

        $("#tag_edit_target").attr("style", "display: none;");
        $("#tag_edit_pool").attr("style", "display: none;");
        $("#tag_edit_proxyprotocol").attr("style", "display: none;");
        $("#tag_edit_https").attr("style", "display: none;");
        $("#tag_edit_cert").attr("style", "display: none;");
        $("#tag_edit_key").attr("style", "display: none;");
        $("#tag_edit_minspeed").attr("style", "display: none;");
        $("#tag_add_targets").empty();
        $("#tag_edit_targets").empty();
        $("#tag_add_paths").empty();
        $("#tag_edit_paths").empty();
        $("#edit_path").val("");

        switch (response.Rule.Protocol) {
          case "secure_server": {
            $("#tag_edit_target").removeAttr("style");
            $("#tag_edit_key").removeAttr("style");
            break;
          }

          case "secure_client": {
            $("#tag_edit_target").removeAttr("style");
            $("#tag_edit_proxyprotocol").removeAttr("style");
            $("#tag_edit_pool").removeAttr("style");
            $("#tag_edit_key").removeAttr("style");
            break;
          }

          case "tls_server": {
            $("#tag_edit_target").removeAttr("style");
            $("#tag_edit_cert").removeAttr("style");
            $("#tag_edit_key").removeAttr("style");
            break;
          }

          case "tls_client": {
            $("#tag_edit_target").removeAttr("style");
            $("#tag_edit_proxyprotocol").removeAttr("style");
            $("#tag_edit_pool").removeAttr("style");
            break;
          }

          case "quic_server": {
            $("#tag_edit_target").removeAttr("style");
            $("#tag_edit_cert").removeAttr("style");
            $("#tag_edit_key").removeAttr("style");
            break;
          }

          case "quic_client": {
            $("#tag_edit_target").removeAttr("style");
            $("#tag_edit_proxyprotocol").removeAttr("style");
            break;
          }

          case "websocket_server": {
            $("#tag_edit_target").removeAttr("style");
            $("#tag_edit_cert").removeAttr("style");
            $("#tag_edit_key").removeAttr("style");
            break;
          }

          case "websocket_client": {
            $("#tag_edit_target").removeAttr("style");
            $("#tag_edit_proxyprotocol").removeAttr("style");
            $("#tag_edit_pool").removeAttr("style");
            break;
          }

          case "cloudflare": {
            if (response.Rule.Cert != "" && response.Rule.Key != "") {
              $("#edit_https").click();
            }

            $("#tag_edit_https").removeAttr("style");
            $("#tag_edit_path").removeAttr("style");
            $("#tag_edit_minspeed").removeAttr("style");
            break;
          }
        }

        if (response.Rule.Targets != null) {
          for (id in response.Rule.Targets) {
            var html = `<li target="${id}" class="mdui-list-item">
  <div class="mdui-list-item mdui-textfield">
      <input target="${id}" class="mdui-textfield-input" type="text" placeholder="127.0.0.1" />
  </div>
  <div class="mdui-list-item mdui-textfield">
      <input target="${id}" class="mdui-textfield-input" type="number" min="1" max="65535" placeholder="8080" />
  </div>
  <button target="${id}" class="mdui-btn mdui-btn-icon mdui-btn-raised mdui-shadow-4 mdui-color-theme mdui-ripple">
      <i class="mdui-list-item-icon mdui-icon material-icons">delete</i>
  </button>
</li>`;

            $("#tag_edit_targets").append(html);
            $(`input[target="${id}"][type=text]`).val(
              response.Rule.Targets[id].Host
            );
            $(`input[target="${id}"][type=number]`).val(
              response.Rule.Targets[id].Port
            );
            $(`button[target="${id}"]`).on("click", function () {
              $(`li[target="${id}"]`).remove();
            });
          }
        }

        if (response.Rule.Paths != null) {
          for (path in response.Rule.Paths) {
            var html = `<li path="${path}" class="mdui-list-item">${path}
      <div class="mdui-list-item mdui-textfield">
      <input path="${path}" class="mdui-textfield-input" type="text" placeholder="127.0.0.1:8080" />
    </div>
    <button path="${path}"
      class="mdui-btn mdui-btn-icon mdui-btn-raised mdui-shadow-4 mdui-color-theme mdui-ripple">
      <i class="mdui-list-item-icon mdui-icon material-icons">delete</i>
    </button>
  </li>`;
            $("#tag_edit_paths").append(html);
            $(`input[path="${path}"]`).val(response.Rule.Paths[path]);
            $(`button[path="${path}"]`).on("click", function () {
              $(`li[path="${path}"]`).remove();
            });
          }
        }

        editRule.open();
      } else sendmsg(response.Msg);
    })
    .fail(function () {
      sendmsg("请求失败, 请检查网络是否正常");
    });
}

function delete_rule(id) {
  mdui.confirm("删除后规则无法被恢复", "确认删除", function () {
    $.ajax({
      method: "GET",
      url: "/api/delRule?id=" + id,
      dataType: "json",
    })
      .done(function (response) {
        if (response.Ok) {
          sendmsg("删除成功");
          location.reload();
        } else sendmsg(response.Msg);
      })
      .fail(function () {
        sendmsg("请求失败, 请检查网络是否正常");
      });
  });
}
