function sendmsg(msg) {
    mdui.snackbar({
        message: msg,
        position: 'top',
    });
}
